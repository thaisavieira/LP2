using System.Diagnostics.Eventing.Reader;
using System.Net.Quic;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double imc, altura, peso;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso/(altura * altura);
            imc = Math.Round(imc, 1);
            txtIMC.Text = imc.ToString("F2");
            if (imc < 18.5)
            {
                txtClassIMC.Text = "Magreza";
                txtGrauIMC.Text = "0";
            }
            else if (imc <= 24.9)
            {
                txtClassIMC.Text = "Normal";
                txtGrauIMC.Text = "0";
            }
            else if (imc <= 29.9)
            {
                txtClassIMC.Text = "Sobrepeso";
                txtGrauIMC.Text = "I";
            }
            else if (imc <= 39.9)
            {
                txtClassIMC.Text = "Obesidade";
                txtGrauIMC.Text = "II";
            }
            else
            {
                txtClassIMC.Text = "Obesidade grave";
                txtGrauIMC.Text = "III";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            imc = 0;
            peso = 0;
            altura = 0;
            txtClassIMC.Clear();
            txtGrauIMC.Clear(); 
            txtIMC.Clear();
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
                return;

            if (!double.TryParse(mskbxPeso.Text, out peso) || (peso <= 0)){
                MessageBox.Show("Peso invalido");
                mskbxPeso.Focus();
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
                return;

            if (!double.TryParse(mskbxAltura.Text, out altura) || (altura <= 0)){
                MessageBox.Show("Altura invalida");
                mskbxAltura.Focus();
            }
        }
    }
}
