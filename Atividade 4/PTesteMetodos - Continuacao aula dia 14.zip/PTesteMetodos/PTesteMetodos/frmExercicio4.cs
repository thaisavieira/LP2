﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContNum_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contaNum = 0;

            while (posicao < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[posicao]))
                {
                    contaNum++;
                }
                posicao++;
            }
            MessageBox.Show($"A frase tem {contaNum} numeros");
        }

        private void btnCharBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++) 
            { 
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }

            if (posicao > 0)
                MessageBox.Show($"O 1° caracter branco esta na posição {posicao}");
            else
                MessageBox.Show("Não ha caracteres em branco");

        }

        private void btnContLetras_Click(object sender, EventArgs e)
        {
            int contLetra = 0;
            foreach (char c  in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contLetra++;
                }
            }
            MessageBox.Show($"A frase tem {contLetra} letras");
        }
    }
}
