﻿namespace PTesteMetodos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            menuStrip1 = new MenuStrip();
            exercicío1ToolStripMenuItem = new ToolStripMenuItem();
            copiarToolStripMenuItem = new ToolStripMenuItem();
            colarToolStripMenuItem = new ToolStripMenuItem();
            exercicío2ToolStripMenuItem = new ToolStripMenuItem();
            exercicíoToolStripMenuItem = new ToolStripMenuItem();
            exercicío4ToolStripMenuItem = new ToolStripMenuItem();
            exercicío5ToolStripMenuItem = new ToolStripMenuItem();
            sairToolStripMenuItem = new ToolStripMenuItem();
            contextMenuStrip1 = new ContextMenuStrip(components);
            editorToolStripMenuItem = new ToolStripMenuItem();
            calculadoraToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            contextMenuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { exercicío1ToolStripMenuItem, exercicío2ToolStripMenuItem, exercicíoToolStripMenuItem, exercicío4ToolStripMenuItem, exercicío5ToolStripMenuItem, sairToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(4, 1, 0, 1);
            menuStrip1.Size = new Size(635, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // exercicío1ToolStripMenuItem
            // 
            exercicío1ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { copiarToolStripMenuItem, colarToolStripMenuItem });
            exercicío1ToolStripMenuItem.Name = "exercicío1ToolStripMenuItem";
            exercicío1ToolStripMenuItem.Size = new Size(75, 22);
            exercicío1ToolStripMenuItem.Text = "Exercicío &1";
            exercicío1ToolStripMenuItem.Click += exercicío1ToolStripMenuItem_Click;
            // 
            // copiarToolStripMenuItem
            // 
            copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            copiarToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.C;
            copiarToolStripMenuItem.Size = new Size(151, 22);
            copiarToolStripMenuItem.Text = "Copiar";
            copiarToolStripMenuItem.Click += copiarToolStripMenuItem_Click;
            // 
            // colarToolStripMenuItem
            // 
            colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            colarToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.V;
            colarToolStripMenuItem.Size = new Size(151, 22);
            colarToolStripMenuItem.Text = "Colar";
            colarToolStripMenuItem.Click += colarToolStripMenuItem_Click;
            // 
            // exercicío2ToolStripMenuItem
            // 
            exercicío2ToolStripMenuItem.Name = "exercicío2ToolStripMenuItem";
            exercicío2ToolStripMenuItem.Size = new Size(75, 22);
            exercicío2ToolStripMenuItem.Text = "Exercicío &2";
            exercicío2ToolStripMenuItem.Click += exercicío2ToolStripMenuItem_Click;
            // 
            // exercicíoToolStripMenuItem
            // 
            exercicíoToolStripMenuItem.Name = "exercicíoToolStripMenuItem";
            exercicíoToolStripMenuItem.Size = new Size(75, 22);
            exercicíoToolStripMenuItem.Text = "Exercicío &3";
            exercicíoToolStripMenuItem.Click += exercicíoToolStripMenuItem_Click;
            // 
            // exercicío4ToolStripMenuItem
            // 
            exercicío4ToolStripMenuItem.Name = "exercicío4ToolStripMenuItem";
            exercicío4ToolStripMenuItem.Size = new Size(75, 22);
            exercicío4ToolStripMenuItem.Text = "Exercicío &4";
            exercicío4ToolStripMenuItem.Click += exercicío4ToolStripMenuItem_Click;
            // 
            // exercicío5ToolStripMenuItem
            // 
            exercicío5ToolStripMenuItem.Name = "exercicío5ToolStripMenuItem";
            exercicío5ToolStripMenuItem.Size = new Size(75, 22);
            exercicío5ToolStripMenuItem.Text = "Exercicío &5";
            exercicío5ToolStripMenuItem.Click += exercicío5ToolStripMenuItem_Click;
            // 
            // sairToolStripMenuItem
            // 
            sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            sairToolStripMenuItem.Size = new Size(38, 22);
            sairToolStripMenuItem.Text = "&Sair";
            sairToolStripMenuItem.Click += sairToolStripMenuItem_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(24, 24);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { editorToolStripMenuItem, calculadoraToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(138, 48);
            // 
            // editorToolStripMenuItem
            // 
            editorToolStripMenuItem.Name = "editorToolStripMenuItem";
            editorToolStripMenuItem.Size = new Size(137, 22);
            editorToolStripMenuItem.Text = "Editor";
            // 
            // calculadoraToolStripMenuItem
            // 
            calculadoraToolStripMenuItem.Name = "calculadoraToolStripMenuItem";
            calculadoraToolStripMenuItem.Size = new Size(137, 22);
            calculadoraToolStripMenuItem.Text = "Calculadora";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(635, 278);
            ContextMenuStrip = contextMenuStrip1;
            Controls.Add(menuStrip1);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            contextMenuStrip1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem exercicío1ToolStripMenuItem;
        private ToolStripMenuItem exercicío2ToolStripMenuItem;
        private ToolStripMenuItem exercicíoToolStripMenuItem;
        private ToolStripMenuItem copiarToolStripMenuItem;
        private ToolStripMenuItem colarToolStripMenuItem;
        private ToolStripMenuItem exercicío4ToolStripMenuItem;
        private ToolStripMenuItem exercicío5ToolStripMenuItem;
        private ToolStripMenuItem sairToolStripMenuItem;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem editorToolStripMenuItem;
        private ToolStripMenuItem calculadoraToolStripMenuItem;
    }
}
