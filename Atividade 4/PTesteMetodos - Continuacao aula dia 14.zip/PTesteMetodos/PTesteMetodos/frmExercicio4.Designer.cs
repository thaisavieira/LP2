﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnContLetras = new Button();
            btnCharBranco = new Button();
            btnContNum = new Button();
            rchtxtFrase = new RichTextBox();
            SuspendLayout();
            // 
            // btnContLetras
            // 
            btnContLetras.Location = new Point(523, 309);
            btnContLetras.Name = "btnContLetras";
            btnContLetras.Size = new Size(150, 91);
            btnContLetras.TabIndex = 14;
            btnContLetras.Text = "Conta Letras";
            btnContLetras.UseVisualStyleBackColor = true;
            btnContLetras.Click += btnContLetras_Click;
            // 
            // btnCharBranco
            // 
            btnCharBranco.Location = new Point(323, 309);
            btnCharBranco.Name = "btnCharBranco";
            btnCharBranco.Size = new Size(150, 91);
            btnCharBranco.TabIndex = 13;
            btnCharBranco.Text = "Localiza 1° caracter em branco";
            btnCharBranco.UseVisualStyleBackColor = true;
            btnCharBranco.Click += btnCharBranco_Click;
            // 
            // btnContNum
            // 
            btnContNum.Location = new Point(123, 309);
            btnContNum.Name = "btnContNum";
            btnContNum.Size = new Size(150, 91);
            btnContNum.TabIndex = 12;
            btnContNum.Text = "Conta números";
            btnContNum.UseVisualStyleBackColor = true;
            btnContNum.Click += btnContNum_Click;
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(124, 21);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(550, 259);
            rchtxtFrase.TabIndex = 15;
            rchtxtFrase.Text = "";
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(rchtxtFrase);
            Controls.Add(btnContLetras);
            Controls.Add(btnCharBranco);
            Controls.Add(btnContNum);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
        }

        #endregion

        private Button btnContLetras;
        private Button btnCharBranco;
        private Button btnContNum;
        private RichTextBox rchtxtFrase;
    }
}