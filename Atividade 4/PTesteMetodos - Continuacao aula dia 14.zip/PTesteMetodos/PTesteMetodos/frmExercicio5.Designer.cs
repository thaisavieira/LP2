﻿namespace PTesteMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSortear = new Button();
            lblNumero2 = new Label();
            lblNumeo1 = new Label();
            txtNumero2 = new TextBox();
            txtNumero1 = new TextBox();
            SuspendLayout();
            // 
            // btnSortear
            // 
            btnSortear.Location = new Point(62, 116);
            btnSortear.Margin = new Padding(2);
            btnSortear.Name = "btnSortear";
            btnSortear.Size = new Size(105, 44);
            btnSortear.TabIndex = 18;
            btnSortear.Text = "Sortear";
            btnSortear.UseVisualStyleBackColor = true;
            btnSortear.Click += btnSortear_Click;
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(13, 65);
            lblNumero2.Margin = new Padding(2, 0, 2, 0);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(60, 15);
            lblNumero2.TabIndex = 17;
            lblNumero2.Text = "Numero 2";
            // 
            // lblNumeo1
            // 
            lblNumeo1.AutoSize = true;
            lblNumeo1.Location = new Point(13, 22);
            lblNumeo1.Margin = new Padding(2, 0, 2, 0);
            lblNumeo1.Name = "lblNumeo1";
            lblNumeo1.Size = new Size(60, 15);
            lblNumeo1.TabIndex = 16;
            lblNumeo1.Text = "Numero 1";
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(130, 62);
            txtNumero2.Margin = new Padding(2);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(105, 23);
            txtNumero2.TabIndex = 15;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(130, 19);
            txtNumero1.Margin = new Padding(2);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(105, 23);
            txtNumero1.TabIndex = 14;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(246, 189);
            Controls.Add(btnSortear);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumeo1);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSortear;
        private Label lblNumero2;
        private Label lblNumeo1;
        private TextBox txtNumero2;
        private TextBox txtNumero1;
    }
}